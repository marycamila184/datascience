#pacote com recurso de text mining
library(tm)

#Lista todos os arquivos .txt no diretorio
filenames <- list.files(getwd(),pattern="*.txt")

#ler os arquivos em um vetor de caracteres
files <- lapply(filenames,readLines)

#criar um crpus a partir do vetor
docs <- Corpus(VectorSource(files))

#inspeciona um documento no corpus (verifica se esta' ok)
writeLines(as.character(docs[[1]]))

#-------------INICIO DO PREPROCESSAMENTO--------------

#Transformar para minusculo
docs <-tm_map(docs,content_transformer(tolower))

#Remover pontuacao 
docs <- tm_map(docs, removePunctuation)
#Remover digitos
docs <- tm_map(docs, removeNumbers)
#remover stopwords
docs <- tm_map(docs, removeWords, stopwords("english"))
#remover espacos em branco
docs <- tm_map(docs, stripWhitespace)

#definir e eliminar algumas palavras especificas (stopwords especificas)
myStopwords <- c("can", "say","one","way","use","also","howev","tell","will","much","need","take","tend","even","like","particular","rather","said","get","well","make","ask","come","end","first","two","help","often","may","might","see","someth","thing","point", "post","look","right","now","think","‘ve ","‘re ","anoth","put","set","new","good","want","sure","kind","larg","yes,","day","etc","quit","sinc","attempt","lack","seen","awar","littl","ever","moreov","though","found","abl","enough","far","earli","away","achiev","draw","last","never","brief","bit","entir","brief","great","lot")
docs <- tm_map(docs, removeWords, myStopwords)

#Criar um document-term matrix
dtm <- DocumentTermMatrix(docs)


#--------PROCEDIMENTOS DO LDA---------#

library(topicmodels)

#Rodar o LDA com Gibbs Sampling - usando configuracoes padrao
k<-5
ldaOut <- LDA(dtm,k, method="Gibbs")

#Imprimindo os resultados
#documentos para topicos
ldaOut.topics <- as.matrix(topics(ldaOut))

#top 5 termos em cada topico
ldaOut.terms <- as.matrix(terms(ldaOut,5))

#Probabilidades associadas a cada topico 
topicProbabilities <- as.data.frame(ldaOut@gamma)

